# Validation

- Node syntax checks passed for app.js and engine.js.
- Five domain tests passed: authorization/match/pickup lifecycle; expiry cancellation; closing inventory cancellation; shared bundle and merchant consent; local persistence.
- Browser verified: Home, split search, detail/first-use, immediate successful matching, waiting authorization, live countdown, three-second expiration and authorization cancellation, merchant confirmed queue, preparing/ready, customer pickup completion, history, profile, closing reservation, inventory persistence after refresh, shared closing bundle, cancellation, merchant menu publication, share-card preview, mobile layout.
- External images rendered successfully in the preview. Hosting was not completed: Sites source push first failed network connectivity, then automatic approval review rejected the stdin/source-upload step. No live deployment is claimed.
- Desktop breakpoint, generated PNG download, all filter combinations, closing creation form and inventory editing were implemented but not exhaustively browser-tested. No production backend or payments exist.

## Version 2 validation

- 11 domain tests pass, including one-menu/two-package gross economics, distinct pickup codes, independent package pickup, repeat ordering in new rounds, historical package isolation, same-quantity closing discounts, dine-in method/window consistency, and legacy migration.
- Browser verified at 390px: hero CTA fully inside banner (28px bottom clearance) with no horizontal overflow. 320px and 1280px checks also passed CTA containment and overflow checks.
- Browser verified: consumer inclusive pricing, first-use join, dedicated matching success screen, payment confirmation, merchant total 25,000 won with A/B packages and distinct codes, common preparation/ready transitions, A collected with B still waiting, new-round reorder and fresh authorization/countdown, presenter-simulated matching success, matched feed without recruiting countdown, separate profile metrics, hidden presenter entry, and persisted package state after refresh.
- Browser captured no console errors during final flow verification.
- Static syntax check passed after final UI copy changes. Food imagery and font assets still require internet. Multi-user, merchant and payment flows remain local simulations. Fixed fulfillment windows are fictional presentation data.
- Hosting remains undeployed because the prior Sites source-upload approval block has not been resolved. This update is delivered locally and as a separate v2 archive.


## Version 3 validation

21 tests pass (11 existing + 10 targeted regressions). Regressions cover cancelled-order resurrection through preparation/pickup; zero-participant method release and remaining-participant locking; configured duration and dynamically valid pickup; before-open/late/after-close rejection; finite shared-bundle hold/release/consumption; immutable closing pickup cutoff; service-clock expiry; custom merchant duration persistence; equal-quantity original price/purchase/savings in both share content and PNG drawing calls.

Mobile browser verified at 390×844: dine-in join → cancel → same-round pickup rejoin → simulated matching → merchant preparing/ready → old order still cancelled with authorization cancelled. Refresh preserved terminal state. Sticky checkout was visible before scrolling and repeated policy was collapsed. No captured console errors in the final check. Map pins showed chicken 12,500 won and pizza 14,500 won. Advancing the displayed demo clock to 22:10 disabled the next chicken round with an operating-time explanation. Closing share preview showed 24,000 → 9,900 and 14,100 saved. Download click executed, but automation's download event timed out; disk receipt was not verified. PNG content is covered by the shared-renderer regression.

The browser was returned to clean demo data at 19:00. Existing v1/v2 ZIPs were retained; v3 is a separate ZIP. Hosting remains subject to the previously reported source-upload approval block; this version is local.


## Version 4 validation

28 tests passed. Added regressions for exact 20:30–21:00 registration in menu/round/order, non-rounded 20:31–21:16 duration, rejecting insufficient initial preparation time without silently moving the window or inserting a menu, fresh merchant-created bridge stock/match/three-package pickup/restart/expiry, unchecked ordinary closing mode, invalid prices/stock/split/consent, and real timestamp-derived split share copy used by PNG drawing.

Browser at 390px: closing share card right edge 336px, modal right edge about 375px; modal scrollWidth equalled clientWidth (360px), footer inside card. Split share fit at 320/390/430px without horizontal overflow. Merchant created “새안암 베이크 / 네 개씩 담은 빵 묶음”, normal 30,000, closing total 15,000, stock 2, three portions and fee 300. Merchant showed 1 unallocated bundle plus 1 held round. Customer saw 5,300 per portion and exact 20:30–21:00 pickup. Simulated matching created one 15,900-won group with A/B/C distinct codes. Dine-in pizza success displayed individual plating/seating at a shared service window. Personalized share showed 28,000-won menu versus 14,500 for my portion and recorded immediate matching. No captured console errors.

PNG uses the same content model and renderer text tests; visual receipt of an exported PNG file has not been confirmed by the in-app download tool. This remains a local prototype; prior hosting upload block is unchanged. v4 ZIP is separate from all earlier archives.


## Version 5 validation

40 tests passed (28 prior tests, with success-share fixtures now explicitly representing confirmed orders, plus 12 quantity/stage tests). Actual two-identity join tests filled a three-portion round as A2+B1. Verified oversell/noninteger rejection without state mutation, exact cancellation restoration, full-amount expiry, A's multiple packs sharing one code, independent B pickup, order-based fees with two-portions-per-pack, JSON/local persistence, equal-quantity savings, invitation/waiting/success/closing states, category/photo/unit registration and merchant preview totals.

Mobile browser verified: shared bakery quantity two gives product 10,000 + portion fees 600 = 10,600, two physical packs and one code. Pre-order invitation says “할인 기회 / 아직 주문 전”; waiting share says one portion still required. Cancelling restored the ability to select all three portions. Rejoining two portions and presenter matching produced A2+B1, total 15,900, three packs and two customer codes. Merchant A pickup collected both A packs while B remained waiting. My BITE displayed two portions, one transaction and 9,400 closing discount. Refresh preserved quantity, amount and code; simulated B was absent from My Orders.

Merchant browser registered a pizza with pizza category/photo, “피자 반판 · 4조각” label and exact 20:30–21:00 pickup. It appeared under the pizza filter with the correct photo. Registration summary displayed A2+B1 15,900/three packs for portion-based fees; switching to order-based fees and capacity two changed A's charge to 10,300, total to 15,600 and packs to two. A real frontend order with those settings showed the correct 10,300 authorization and one pack; its three-second expiry retained quantity two and cancelled the complete authorization.

Quantity-aware success shares had no horizontal overflow at 320/390/430px. No captured console errors during the final expiry check. Exported PNG file receipt remains unconfirmed by the in-app download tool; PNG text/content paths are unit-tested. Real backend identity, simultaneous network transactions and payments remain out of scope. v5 archive is separate; previous archives retained. Hosting upload blocker unchanged.


## v6 validation
- 49 automated tests passed, including nine new table-service tests: two tables/two guests buying one half-plate each; guest/quantity independence; invalid/duplicate tables; compatible service slots; separate plating fees; kitchen transitions; independent/idempotent service; cancellation/expiry; persisted table/plate/code ownership; presenter table simulation; merchant and sharing models.
- Browser verified: table 3, party 2, quantity 1, ₩15,000 authorization → simulated table 7 → ₩30,000 full-menu order / two plates. Kitchen prepared both; table 3 served while table 7 stayed ready, then table 7 completed. Customer completed history correctly showed served and retained order confirmation code.
- 390px viewport checked: merchant page document width 375px, no horizontal overflow. Verified dine-only merchant form preview and distinct zero plating fee. Browser console reported no errors during these checks.
- Local demo only. No real table session validation, live multi-user synchronization, POS, payment, or public hosting verification. Downloaded PNG visual inspection was not repeated in this iteration.


## v7 validation
- 62 automated tests passed (previous 49 plus 13 customer-request tests). Cases cover no authorization on request or merchant approval, explicit acceptance of revised exact amount, rejection, customer cancellation, response and offer expiry, existing-round reuse, changed ratios requiring review, independent table service after request matching, persistence of requested/proposed/accepted terms, atomic failed acceptance, invalid quantities/tables, stage-specific shares, two customer requests merging into one round, multi-portion per-order fees and full authorization cancellation on failure.
- Browser exercised new request for modum fried platter: table 3, party 2, half plate one item, service 20:00–20:30. Merchant offered ₩13,000 + ₩300. Customer reviewed exact ₩13,300 before explicit acceptance. Waiting order showed authorization only. Presenter matched simulated table 7, resulting in ₩26,600 one-menu/two-plate kitchen order. After preparation, table 3 served independently while table 7 stayed ready.
- Reload retained accepted request, approved conditions, linked order and table. At 390px viewport document width was 375px, with no horizontal overflow in request review and merchant views. Dine filter / low-price sorting displayed chicken ₩12,000 and detail also ₩12,000. Console checks reported no errors.
- Screenshot evidence: ../BITE-v7-table-proof.png. Native PNG card download was not visually rechecked; shared content model is covered by tests.
- No public hosting deployment or real merchant/payment integration is claimed.


## v8 validation
- 72 automated tests pass: prior 62 with invalid-time regression updated to require rejection at proposal time, plus ten new v8 tests. New coverage: impossible/out-of-hours/inverted windows; match plus prep margin; operational expiry before response timeout; expired and unexpired revisions; stale acceptance version rejected; general-menu publication without orders; blocked-menu consent and toggling; eligibility revocation; persistence; invalid catalog settings.
- Browser: merchant registered ‘철판 소시지 모둠’ as a new general menu, customer found it under store menus alongside preapproved and unavailable menus, and table 4 requested one half plate for two guests. A near-immediate service proposal was rejected while preserving the review form. Valid 20:20–20:50 proposal was sent; moving demo time to 19:58 caused operational expiry. Merchant revised to 20:40–21:10. Customer saw explicit time, price, composition and fee differences, accepted ₩13,300, and entered matching with authorization only.
- 390px viewport: request comparison document width 375px, no horizontal overflow. Both home primary actions fit inside the hero and were visible. General menu registration, store discovery and unavailable-menu explanation verified. Existing orders retained across reload. Screenshots: ../BITE-v8-home.png and ../BITE-v8-conditions.png.
- No real payment, merchant authentication, cross-device sync, table QR or public hosting claim. PNG share export was not visually rechecked in v8.


## v9 validation
- 80 automated tests pass: previous 72 (discounted legacy scenarios now explicitly provide merchant discount consent) plus eight v9 tests. Coverage: product shortfall cannot be hidden by fees; full menu value preserved by default; exact discount acknowledgment and re-acknowledgment; original price / actual proceeds / authorized amount / share / savings consistency; legacy migration without changing charges or inventing approval; per-order fee ranges; first-response funnel metrics; presentation storage leaves ordinary saved data unchanged.
- Browser tested new presentation session, customer table-3 half-platter request, merchant 13,000 product + 300 fee offer. Review showed original 32,000, product total 26,000, fees 600, revenue 26,600 and required 6,000 discount. Sending without consent kept the form open. Explicit consent allowed proposal, home showed one answer notification, customer accepted 13,300 and presenter matched table 7.
- Merchant matched order showed original 32,000 / products 26,000 / fees 600 / actual 26,600 and explicit discount. Share referred to original 32,000. After table-3 service, My BITE showed 18,700 reduced whole-menu spend, separately from closing discounts. Business funnel showed its sample counts and simulation label.
- 390px viewport document width 375px: no horizontal overflow on merchant economics screen. Presentation exit returned to the previous normal service clock/state; re-entering and reloading retained a clean presentation session and open recommendations. Console errors and final layout checked before packaging.
- Screenshot evidence: ../BITE-v9-economics.png and ../BITE-v9-presentation.png. Real payment, merchant consent authentication, server notifications, cross-device sync and public hosting remain outside this prototype.
