# BITE · Anam Beta

먹고 싶은 만큼만. A standalone, mobile-first consumer MVP. This project was created independently; no Nomi source or project was used or changed.

## Run

No dependencies or API keys. From this folder: `npm start`, then open `http://127.0.0.1:5173`. Or serve `dist/` using any static HTTP server. ES modules require HTTP rather than opening index.html directly. Run `npm test` for matching/payment/inventory/persistence checks.

## Product

**같이먹기** aggregates demand for a normal menu. Participating merchants define standard portions, split count, packaging fees, pickup/dine-in methods, and hours. The store portions and packages food; customers never meet or divide it. Only matched transactions reach the merchant queue. **오늘마감** sells existing closing inventory. **같이 나누기** applies matching to a larger closing bundle.

Only merchant-approved listings participate. Easy-to-portion menus are deliberately selected. Portion composition is explicit. Dine-in uses one compatible preparation window, with separate plating and seating. Delivery is a future beta concept, not an operational service in this MVP.

## Implemented

- Five consumer destinations, search, categories, distance/price/closing sorting, fulfillment filters, detail sheets, local discovery map.
- Live countdown, participant counts, first-use explanation, join, authorization, matching, expiry, authorization cancellation, eligible cancellation/refund simulation.
- Independent pickup codes, merchant preparing/ready/picked transitions, order tabs and completed-order reviews.
- Closing inventory reservation and restoration, shared closing bundle matching, save, feed likes, share-link generation, downloadable 1080×1920 PNG story cards.
- Merchant opt-in creation forms with split sizes, composition, fees, hours and methods; closing deals; inventory editing; confirmed-only queue.
- Local persistence of listings, orders, reviews, saves and profile totals. Profile starts honestly at zero and changes after completed orders.
- Hidden presenter entry (`?presenter=1`, Ctrl+Shift+D, or five taps on the footer BITE Beta label) exposes per-order second-participant matching and a three-second expiry control. Data reset requires confirmation. First chicken has one seeded participant and matches immediately on joining; pizza starts at zero and demonstrates authorization/waiting.
- Internal business brief and five-minute demo outline, accessible from My BITE or desktop sidebar.

## State & architecture

`engine.js` contains matching, inventory, payment and order transitions independent of rendering. `app.js` renders UI and delegates actions. `style.css` handles responsive layout. Seeded data represents User, Merchant/Menu, ClosingDeal and separate matching rounds; listings project only their current round for discovery. Historical rounds retain preparation totals, participants and independently fulfilled packages; orders contain SplitParticipant, PaymentAuthorization and Pickup; Review is stored separately and ShareCard is generated from the order/listing. Merchants and menus are embedded in listings for this small prototype; production should normalize them.

Open / Almost Matched are derived from joined/required; orders use waiting → matched → preparing → ready → picked. Waiting can expire or cancel. Closing reservations use reserved → preparing. Payment authorization is never presented as a charge. Match changes authorization to confirmed; expiry/cancel changes it to cancelled. Cancelling a reservation simulates a refund.

## Anam strategy and economics

Start with 3–5 merchants, 5–10 menus, a few closing partners, a small student community, and pickup within roughly 1km. Density creates faster matching, repeat use, merchant adoption and menu selection. Transaction data can later improve demand insights and merchant retention.

Consumers use BITE free. Revenue hypothesis: small transaction commissions, then optional Merchant Pro analytics/POS integrations. Packaging/portioning compensation is transparent and merchant-defined. During the pilot, waive or heavily reduce fees to validate incremental demand. Example: a ₩24,000 chicken plus two ₩500 packaging fees yields ₩25,000 gross; no forced discount. A hypothetical 3% commission would leave ₩24,250 before merchant costs; actual fee structure must preserve merchant economics and be validated.

Pilot metrics: match rate, median match time, 30-day repeat usage, incremental orders (survey/counterfactual), match failure rate, pickup completion, and closing sell-through. **Hypothetical target, not achieved:** 70% of popular Split listings match within 10 minutes. No real partnerships or achieved pilot results are claimed. Existing sharing and closing-discount services may exist; BITE's differentiation is restaurant-supported portions without coordination between strangers, combined with closing inventory sales.

## Simulations and limitations

All merchants, activity, stock, distances and time windows are fictional. Food photos are illustrative external Unsplash assets; Google Fonts and photos require internet. The map is a deliberately labeled schematic. Each browser is one user, not a real multi-user marketplace. Demo Mode represents other participants. No payments, notifications, QR scanner, routing, POS, legal compliance certification or merchant integration is implemented. Pickup codes are UI concepts, not secure credentials. Closing reservation is explicitly simulated. Initial fulfillment windows are fictional fixtures. Version 3 uses an explicitly labelled Anam demo service clock (starts at 19:00 KST and advances with real elapsed time), validated operating/preparation windows and bounded closing inventory. Matching deadlines are wall-clock timers persisted across refresh.

Profile shows two separate metrics: Split reduced spending versus buying the full menu, and Closing discount versus the same quantity at normal price. Shared closing bundles compare only the purchased fraction of normal value. Both subtract packaging fees; a ⅓ portion of a ₩30,000 box bought for ₩5,000 + ₩300 packaging yields ₩4,700 discount, never ₩24,700. Food-waste impact uses an unvalidated 0.34kg-per-completed-order assumption and is secondary, labeled accordingly. Profile totals are derived from locally completed orders in the current calendar month.

## Production and iOS path

Move domain transitions behind authenticated APIs with atomic participant/inventory transactions, server-owned clocks, idempotency, authorization/capture/refund integrations and webhooks. Normalize users, merchants, menus, participants and pickups. Add merchant verification/consent, secure pickup validation, data protection, reconciliation, cancellation/no-show rules, allergen information and food-handling review. Validate real preparation windows and packaging cost with pilot merchants. Reuse domain contracts in a native SwiftUI client; replace local persistence with API and device caches. Keep pickup-first until density and fulfillment reliability support delivery experiments.


## Version 2 — core-flow refinement

- Mobile hero grows with content; primary CTA containment checked at 320px, 390px and desktop. Displayed prices now include packaging from listing to checkout.
- Matching has a dedicated success moment with payment confirmation, fulfillment window and direct order navigation.
- Merchant matching-round view represents one full menu, full revenue plus packaging compensation, and A/B (or more) independently coded packages. Common preparation and package pickup are separate transitions. Other customers are explicitly simulated.
- Current-round state drives cards, feed and detail. Matched rounds no longer display recruitment timers. Expired or completed own orders can start a fresh round through “다음 회차로 주문하기”; old packages and order history remain intact. Version 3 preserves merchant-configured matching duration and recalculates a valid pickup slot; all merchants and service times remain fictional as documented above.
- Profile separates reduced spending from equivalent-quantity discounts. Demo Mode was removed from My BITE and placed behind the presenter entry described above. Bottom navigation uses consistent outlined SVG icons.
- Existing local orders are migrated to rounds while retaining codes, saves and history. No production multi-user matching or payment processing has been added.


## Version 3 — cancellation, scheduling, inventory and sharing

- Cancelled/expired orders are excluded from preparation and pickup propagation. Transitions require a confirmed payment and a valid package link. A cancelled authorization is never recaptured by preparation. Migration restores the terminal state of previously corrupted v2 cancelled orders.
- Zero participants unlock the fulfillment method. If participants remain, incompatible methods are explicitly disabled; the misleading “next round” method text is removed.
- Regular menu restart requires merchant opt-in, operating hours, the configured matching duration plus preparation margin, and a pickup slot ending before closing. Slots use five-minute boundaries and configured pickup duration. Same-day operation only; overnight hours are not supported in this pilot.
- Shared closing bundles use a finite **whole-bundle** inventory. A recruiting round holds one bundle, expiry releases it exactly once, matching consumes it. Another round requires remaining/restocked whole bundles and enough time before the original fixed pickup slot. Merchant stock editing affects unallocated bundles only.
- Every screen shows a clearly labelled demo service clock, initially 19:00 KST. Presenter tools can move this clock to test opening/closing boundaries. It is deliberately separate from wall-clock matching countdowns; production must use server-authoritative time. Moving the clock backwards does not revive expired orders or rounds. Reset demo data for a fresh presentation.
- Map pins now read fee-inclusive prices from the same menu data. Closing share preview and PNG consume `shareContent()` from `share-card.js`: identical original portion value → purchase total, savings, and basis. Shared bundles compare equal quantities.
- Detail has a sticky bottom order action; repetitive payment/cancellation policy is collapsible. Toast notifications no longer intercept bottom navigation taps.
- `npm test` runs all 21 domain and regression tests. Browser verification covered the reported cancel/rejoin/ready sequence, method unlocking, terminal cancelled history after refresh, closing-time restart denial, fee-inclusive map pins, share preview and 390px sticky CTA.
- Download dispatch was exercised, but the in-app browser automation timed out waiting for its download-file event. PNG drawing text is regression-tested against the shared preview content; file-system receipt of the browser download was not confirmed by that tool.


## Version 4 — merchant settings and share polish

- First publication keeps the merchant's exact start and end time (including non-default 30/45-minute windows). Configured window duration is derived from these endpoints, not a hidden 20-minute default. If recruitment plus preparation cannot fit before the supplied start, publication is rejected with an instruction to adjust it; it is never silently shifted. Later repeat rounds may move later, preserving that duration and the existing closing constraints. Historical orders retain their original communicated windows.
- Today-closing registration now includes “여러 명이 나눠 구매 허용”. A merchant sets full bundle normal value, discounted bundle total, unallocated whole-bundle stock, 2–4 participants, per-portion fee, matching/preparation minutes and each customer's exact composition. Registration uses the same bridge inventory, matching and fulfillment engine as seeded bundles. Equal-price bundle portions require a total divisible by participant count. Normal closing registration remains available with the option off.
- Preview cards fit the modal width and grow with content. Floated close controls no longer squeeze/expand the card; the footer flows after the content. Verified no horizontal overflow at 320, 390 and 430px.
- Price sorting uses the fee-inclusive total. Dine-in matching success describes individual plating and separate seating. Split shares show whole-menu value versus my total and derive matching time only from recorded created/matched timestamps (listing previews do not invent a duration). DOM preview and PNG keep the shared content model.
- New `merchant-menu.js` validates form submissions separately from UI. `npm test` now runs 28 tests, including exact merchant windows, insufficient-time rejection without publication, newly registered closing bundles through matching/three-package fulfillment, ordinary closing mode, invalid bundle inputs, and personalized share content.


## Version 5 — buy portions, not headcount

Matching capacity is now measured in portions. `required` is total portions, `joined`/`soldQuantity` are sold portions; they are never a required number of people. A customer chooses 1 through remaining portions before joining. A single order can fill the entire round. Another active order by the same customer/menu is prevented; while waiting, cancel the whole order and reselect quantity. Normal closing reservations also accept quantities up to remaining stock.

`quote(menu, quantity)` is the single pricing/packaging calculation used by checkout, merchant preview and order creation. `Order.quantity` is purchased portions; `unitPrice`/`unitFee` are merchant rates; `price` is the aggregate product amount and `fee` the aggregate fee. Authorization amount is their sum. `feeBasis` is `portion` (rate × quantity) or `order` (rate once). `portionsPerPack` sets standard packing capacity, so physical package count is ceil(quantity / capacity). These are independent settings: two portions can mean two packages or one package, with an explicitly chosen fee basis.

Each customer order has exactly **one pickup code**. `Order.packageIds` links every physical package to that order; packages carry `orderId`, portion quantity and that same code. One confirmation collects that order's packages together without changing other customers. Merchant rounds show the full-menu revenue/fees and customer groups (A 2 portions/2 packs/one code, B 1 portion/1 pack/another code). Preparation remains common to the round. Pickup confirmation is idempotent.

Actual domain tests can call `join(state, menuId, method, quantity, userId)` for two identities; the UI remains a single-user browser-local simulation. Presenter matching fills unsold portions with one simulated customer, not a fake headcount. Simulated orders are excluded from the current user's history and stats. There is still no networked multi-user backend or real payment service.

Cancellation restores the exact quantity and cancels the complete authorization; expiry cancels the complete selected-quantity amount. A matched order cannot be cancelled. Existing v1–v4 local records migrate as quantity-one orders without changing their codes. The initial shared bakery round now starts at 0/3 portions to demonstrate A2 + B1 directly.

### Share stages

- Before ordering: invitation with selected quantity, price, remaining portions and pickup window; no success or “saved money” claim.
- Waiting: remaining portions required to confirm and authorization-only copy.
- Matched: actual ordered quantity, aggregate total and recorded match duration.
- Purchased closing deal/bundle: equivalent normal quantity versus total paid and matching-quantity discount. Two thirds of a 30,000-won normal bundle bought for 10,000 + 600 yields 9,400 saved.
- Ended listings/orders do not produce success cards. DOM preview and PNG still use the same stage-aware content model.

Merchant registration now offers category, a curated demo photo (or automatic category photo), customer-visible amount per portion, fee basis and packing capacity. Live registration summary reconciles an A2+B1 example, per-order payment, whole-round total, physical packs and one-code-per-order rule. For per-order fees, it explicitly notes that total merchant fees depend on the number of orders. Photos are illustrative externally hosted demo assets; upload is not implemented.

`npm test` runs 40 tests. New tests cover actual A2+B1 matching, over-capacity/invalid quantities without mutation, quantity-two cancellation/expiry, charge/package reconciliation for both fee bases, independent multi-package pickup, persistence, quantity-aware discounts/sharing, honest share stages, pizza category/photo/unit and live preview math. Browser checks also verified profile quantities/discounts, correct pizza registration, 320/390/430px share layouts, and a 10,300-won two-portion authorization expiring fully.


## v6 · 테이블마다 반 접시
매장 식사 주문에 테이블 번호와 식사 인원을 연결했습니다. 주문 단위는 매장 지정 몫이며 인원수와 독립적입니다. 예: 3번 테이블 2명 × ½접시, 7번 테이블 2명 × ½접시 → 전체 메뉴 1건, 주방에서 2접시로 준비. 같은 모집 회차와 제공 시간대에서만 매칭합니다. 테이블 번호는 좌석 예약이나 실제 착석 인증이 아닌 데모 입력입니다.

매장은 매장 식사 전용/픽업 병행, 테이블 수, 접시당 몫 수, 플레이팅비 및 주문당/몫당 부과 기준을 설정합니다. 픽업 포장비와 매장 식사 플레이팅비는 별도입니다. 주문 확인 코드 1개로 주문을 식별하며, 매장 식사에서는 고객 픽업 완료 버튼을 제공하지 않습니다.

공통 주방 상태: 매칭 → 조리 → 플레이팅 완료. 이후 매장이 각 테이블의 제공 완료를 개별 확인합니다. 한 테이블의 완료는 다른 테이블에 영향을 주지 않습니다. 모든 접시가 제공되면 회차가 완료됩니다. 주문·테이블·접시·완료 상태는 로컬 저장됩니다. 이전 데모 주문의 누락된 테이블 번호는 임의 생성하지 않으며, 대기 주문은 취소 후 다시 주문해야 합니다.

시연: 홈 ‘테이블마다 반 접시’ → 1몫·3번 테이블·2명 → 참여 → 발표자 모드에서 다른 사용자 참여 → 가상 7번 테이블 매칭 → My BITE / 매장 모드 → 전체 메뉴 조리 → 플레이팅 완료 → 테이블별 제공 완료. 발표자 도구는 ?presenter=1 또는 하단 BITE Beta를 다섯 번 눌러 열 수 있습니다. 초기화는 현재 브라우저의 데모 기록을 지웁니다.

실제 동시 사용자·좌석 인증·주방/POS·결제 연결은 구현하지 않았습니다. 실제 서비스에서는 서버에서 테이블 세션, 원자적 재고/몫 확보, 결제 상태, 매장 권한 및 제공 확인을 관리해야 합니다. 픽업 우선 안암 파일럿 방침은 유지합니다.


## v7 · 손님이 먼저 요청하는 BITE
같이먹기 → 나눠 주문 요청하기에서 매장·메뉴, 희망 분량(½/⅓/¼), 내 개수, 픽업/매장식사, 테이블 번호, 참고 인원, 희망 시간을 선택합니다. 내 요청은 같이먹기 또는 My BITE에서 확인합니다.

매장 제안형과 고객 요청형을 함께 지원합니다. 등록된 참여 메뉴의 동일 분할·시간 조건은 사전 승인 조건으로 제시됩니다. 다른 분량·시간 또는 예시 일반 메뉴 ‘안암 한접시 / 바삭 모둠튀김’은 매장 검토를 거칩니다. 기존 모집이 있으면 작성 화면에서 안내하고, 수락 시 동일 매장·메뉴·분량·구성·가격·소분비·시간·방식의 유효 모집을 재사용합니다.

상태: 요청 접수(매장 검토 중) → 판매 조건 제안 → 고객 수락 → 모집 참여 → 기존 주문 처리. 거절, 요청 취소, 매장 응답 또는 제안 수락 제한 10분 경과도 별도로 표시합니다. 매장 모드의 ‘분할 요청함’에서 승인/조건 제안 또는 거절합니다. 승인 시 개별 분량·전체 분할 수·개별 상품 가격·비용 기준·구성·시간·모집 시간을 확인합니다.

결제 규칙: 요청 작성 및 매장 제안에는 결제 승인이 없습니다. 고객이 표시된 최종 조건을 수락할 때만 주문과 결제 승인을 생성합니다. 전체 몫이 채워져야 결제를 확정하고 주방에 전체 메뉴 주문 1건을 표시합니다. 부족한 수량의 만료 또는 매칭 전 취소는 기존 결제 승인 취소 로직을 사용합니다. 조건 수락은 임시 복제 상태에서 검증한 뒤 반영해 오류 시 메뉴·결제 찌꺼기를 남기지 않습니다. 제공 시간까지 모집·준비 여유가 없어지면 수락을 거절하고 다시 요청하도록 안내합니다.

공유: 검토 전에는 분할 요청 카드, 조건 제안 후에는 조건 확인 전 초대 카드, 참여 후에는 모집 대기 초대, 매칭 후에는 수량·결제액·실제 매칭 시간의 주문 성공 카드입니다. 요청 카드의 미리보기와 PNG는 같은 데이터 모델을 사용합니다. 매장식사 필터에서 카드·정렬·상세 모두 플레이팅비를 사용합니다. 주문 버튼 가까이 모집 마감까지의 시간과 실제 음식 제공/픽업 시간을 구분합니다.

발표 시연: 같이먹기 → 요청하기 → 모둠튀김·반 접시·1개·3번 테이블·2명·20:00–20:30 → 매장 모드 / 분할 요청함 → ₩13,000 + 개당 플레이팅비 ₩300 제안 → My BITE / 내 분할 요청 → 조건 수락 → 내 주문 ₩13,300 승인 대기 → 발표자 모드에서 다른 사용자 참여 → 가상 7번 테이블과 매칭 → 주방 총 ₩26,600 주문 → 조리·플레이팅·각 테이블 제공. 예시 가격은 가상 매장이 자발적으로 제안하는 조건입니다.

구현 범위: 요청 상태, 승인 조건 스냅샷, 수락 후 주문 연결, 테이블/인원 분리, 동일 모집 재사용, 만료·거절·취소, 로컬 저장. 원래 주문·매칭·픽업/테이블 제공 흐름은 유지합니다. requests.js는 요청/승인 도메인을 UI 및 주문 엔진과 분리합니다.

제한: 고객·점주 화면은 같은 브라우저의 시뮬레이션입니다. 매장별 로그인·권한, 실시간 다중 사용자 알림, 서버 동시성, 테이블 QR 인증, 실제 결제, 매장 POS는 미구현입니다. 요청 가능한 일반 메뉴는 데모 카탈로그이며 모든 외부 매장 메뉴를 임의 분할하지 않습니다. 실제 출시에서는 점주 권한, 서버 기반 응답 마감, 조건 버전 확인, 원자적 모집 확보, 결제 멱등성 및 테이블 세션이 필요합니다. iOS에서는 동일 API 기반 요청·승인·주문 모델을 재사용할 수 있습니다.


## v8 · 일반 메뉴에서 시작하는 고객 요청
홈의 주요 행동을 ‘나눠 주문 요청하기’와 ‘지금 열린 모집 보기’로 바꾸고, ‘우리 동네 매장 메뉴’를 추가했습니다. 매장 상세는 메뉴를 분할 조건 사전 승인 / 일반 메뉴·분할 검토 가능 / 분할 제공 불가로 구분합니다. 불가 메뉴에는 요청 버튼 대신 매장 안내를 표시합니다.

매장 모드 → 일반 메뉴 등록에서 매장·메뉴·전체 가격·카테고리·사진·전체 구성·수령 방식·운영 시간·기본 희망 시간·테이블 수·조리 여유를 설정하고 ‘분할 요청 받기’를 선택합니다. 등록은 카탈로그만 추가하며 모집·주문·결제는 생성하지 않습니다. 매장은 메뉴별 요청 받기를 켜거나 끌 수 있습니다. 요청 받기는 판매 조건의 사전 승인이 아닙니다. 기존 ‘같이먹기 메뉴 추가’는 사전 승인 분할 메뉴 등록 경로로 유지합니다.

매장 제안 전송 시 고객 수락 때와 같은 주문 엔진을 임시 상태에서 사용해 운영 시작/종료, 모집 시간, 조리 여유, 제공 구간을 검증합니다. 불가능한 제안은 보내지 않고 입력 화면을 유지합니다. 이미 유효한 모집에 연결할 경우 남은 모집 시간과 조리 시간을 적용합니다. 수락 대기 중인 제안은 10분 응답 제한뿐 아니라 실제 모집·조리 여유가 없어져도 만료됩니다.

매장 요청함에서 ‘시간 수정 · 다시 제안’으로 만료 또는 미수락 제안을 수정할 수 있습니다. 이전 제안 이력과 버전을 보관하며, 고객 수락 버튼의 제안 버전이 현재 버전과 달라지면 결제를 승인하지 않습니다. 수락한 버전과 최종 조건은 주문 연결 기록에 남습니다. 고객 화면에는 요청 당시 참고 상품가와 매장 판매가, 소분비와 부과 기준, 분량, 구성, 제공 시간, 모집/조리 시간의 변경점을 비교합니다. 참고가는 판매 약속이 아닙니다.

시연: 매장 모드에서 ‘철판 소시지 모둠’ 일반 메뉴 등록 → 홈 / 우리 동네 매장 메뉴 → 해당 메뉴 나눠 주문 요청 → 매장 요청함에서 너무 이른 제공 시간을 입력하면 전송 차단 → 유효한 가격·시간·개별 구성 제안 → 데모 시각을 준비 여유 이후로 이동하면 제안 만료 → 매장에서 시간 수정 후 재제안 → 고객이 바뀐 조건 확인·수락 → 기존 모집/결제/테이블 제공 흐름.

데이터: 일반 메뉴 카탈로그는 menus, 판매/모집은 listings/rounds, 고객 요청과 제안 이력은 requests에 분리합니다. merchant-catalog.js는 카탈로그 및 요청 허용 설정, requests.js는 승인·일정 검증·제안 버전, engine.js는 모집·주문·결제를 담당합니다. 기존 브라우저 기록과 신규 일반 메뉴는 로컬 저장됩니다. v7 제안에 조리 여유 필드가 없으면 기존 매장 값 또는 15분을 적용합니다.

제한: 실제 점포 메뉴/POS를 불러오는 기능이나 인증된 점주 계정은 없습니다. 일반 메뉴도 데모 운영자가 직접 등록하는 가상 메뉴입니다. 제안 만료/재제안, 알림, 버전 확인은 같은 브라우저에서 동작하는 시뮬레이션입니다. 실제 출시 시 서버 시계·권한·상태 동기화·고객 알림과 결제 승인의 원자성을 보장해야 합니다. 공개 호스팅 배포는 이번 버전에서 검증하지 않았습니다.


## v9 · 정상가 보존과 매장 매출 보호
원래 전체 메뉴 정상가(originalFull/full), 분할 상품 합계(splitProductTotal), 소분비, 실제 주문 매출을 분리합니다. 고객 요청으로 반 접시 13,000원 × 2를 제안하더라도 원래 모둠튀김 정상가 32,000원은 바뀌지 않습니다.

기본 규칙은 분할 상품 합계가 정상가 이상이어야 한다는 것입니다. 소분비를 상품 차액 보전으로 계산하지 않습니다. 낮은 상품 합계를 제안하려면 매장 화면에서 정상가·상품 합계·소분비 합계·전체 예상 매출·상품 할인 차액을 확인하고 명시적으로 동의해야 합니다. 동의는 정확한 할인 차액과 시각으로 기록됩니다. 상품 가격/전체 분할 수를 바꾸면 화면의 동의 체크가 해제되고, 서버 역할을 하는 도메인 검증도 바뀐 차액에 대한 확인을 요구합니다.

예: 정상가 32,000원 / 상품 26,000원 / 개당 소분비 300원 × 2 / 전체 매출 26,600원 / 상품 할인 6,000원. 이 제안은 6,000원 할인에 동의해야 가능합니다. 고객 수락은 이전과 마찬가지로 13,300원 결제 승인만 생성하고 매칭 시 확정합니다. 주문·My BITE·공유카드는 보존된 32,000원과 실제 내 결제액을 비교합니다. 이 지출 감소는 동일 분량 할인액으로 표시하지 않습니다. 매장 확정 주문에도 원래 정상가와 상품 매출/소분비를 별도로 보여줍니다.

주문당 소분비는 고객 주문 건수에 따라 전체 금액이 달라지므로, 제안 화면은 현재 요청 수량을 반영한 가능한 매출 범위를 표시합니다. 매칭 후에는 실제 주문 건수와 금액을 사용합니다.

기존 요청형 주문은 요청 당시 메뉴 스냅샷으로 원래 정상가를 복원합니다. 과거 결제·실제 상품 매출은 변경하지 않습니다. 예전 저가 거래에 할인 동의 기록을 임의 생성하지 않으며, 매장 화면은 ‘이전 데모 기록 · 할인 승인 이력 없음’으로 표시합니다. 미수락 저가 제안은 새 기준을 충족하거나 할인 동의를 받아 재제안해야 합니다.

홈/Orders에는 매장 답변 도착, 매장 검토 중, 진행 중 주문, 최근 만료·거절 결과 카드를 표시합니다. 요청과 주문 데이터는 별도로 유지하며 고객은 진행 카드에서 연결된 화면으로 돌아갑니다. 홈 추천은 현재 열려 있고 남은 수량이 있는 상품을 먼저 보여주며, 진행 중인 내 주문은 추천에서 제외합니다. 주문 가능한 상품이 없으면 요청 경로를 안내합니다.

발표자 도구(하단 BITE Beta 다섯 번 클릭)의 ‘발표 시작 상태 불러오기’는 19:00, 열린 모집, 주문 없는 시작 상태를 별도 저장 공간에서 엽니다. 평소 bite-anam-v1 기록은 덮어쓰지 않습니다. 발표용 상태에는 상단 배너가 표시되며 ‘평소 기록으로 돌아가기’로 복원합니다. 발표 세션은 별도 로컬 키와 탭 세션 표시를 사용해 새로고침 후에도 유지합니다. 다시 발표 시작을 누르면 발표 상태만 새로 시작합니다.

비즈니스 화면에 고객 요청 운영 지표를 추가했습니다: 최초 매장 응답까지 중앙값, 응답 중 승인/조건 제안 비율, 제안 중 고객 수락률, 수락 후 매칭 성공률. 사전 승인 요청은 수동 매장 응답 집계에서 제외하며 분자/분모와 ‘가상 기록·실제 실적 아님’을 함께 표시합니다. 진행 중 표본도 포함한 현재 관측치이므로 실제 파일럿은 종료 코호트·무응답 편향·점주별 응답을 따로 분석해야 합니다.

모든 거래·할인 동의·지표는 로컬 시뮬레이션입니다. 실제 출시에서는 점주 인증, 원래 정상가 출처 및 버전 관리, 금액에 연결된 할인 동의, 서버 검증, 수수료와 실제 포장 원가를 포함한 정산이 필요합니다. 현재 총매출은 플랫폼 수수료 차감 전이며 순이익을 의미하지 않습니다.
